package ru.family.call;
public class TestCountdown {
    static int tests=0;
    static void check(boolean ok, String msg) { tests++; if (!ok) throw new AssertionError(msg); }
    public static void main(String[] args) {
        int[] choices={30,60,120,180,240};
        for(int activeMinutes:choices){
            for(int buttonMinutes:choices){
                check(SessionSelection.isPresetSelected(true, activeMinutes, buttonMinutes) ==
                     (activeMinutes == buttonMinutes), "highlight active="+activeMinutes+" button="+buttonMinutes);
                check(!SessionSelection.isPresetSelected(false, activeMinutes, buttonMinutes), "inactive must never highlight");
            }
        }
        for(int custom:new int[]{1,45,75,480,1439}){
            check(SessionSelection.isCustomSelected(true,custom), "custom="+custom);
            check(!SessionSelection.isCustomSelected(false,custom), "custom inactive");
        }
        for(int preset: choices) check(!SessionSelection.isCustomSelected(true,preset),"preset must not be custom");
        check(!SessionSelection.isCustomSelected(true,0),"legacy no duration no highlight");
        check(CountdownMath.formatRemaining(1000,7201000).equals("02:00:00"),"2hr countdown");
        check(CountdownMath.formatRemaining(2000,7201000).equals("01:59:59"),"1 second elapsed");
        check(CountdownMath.formatRemaining(5999,6000).equals("00:00:01"),"ceil to second");
        check(CountdownMath.formatRemaining(6000,6000).equals("00:00:00"),"expiry");
        check(CountdownMath.formatRemaining(6600,6000).equals("00:00:00"),"past expiry");
        check(CountdownMath.fractionElapsed(2000,1000,5000)==0.25f,"quarter");
        check(CountdownMath.fractionElapsed(3000,1000,5000)==0.5f,"half");
        check(CountdownMath.fractionElapsed(5000,1000,5000)==1.0f,"complete");
        check(CountdownMath.fractionElapsed(0,1000,5000)==0.0f,"pre-start clamped");
        check(CountdownMath.fractionElapsed(9000,1000,5000)==1.0f,"after end clamped");
        check(CountdownMath.fractionElapsed(1000,0,5000)==0.0f,"legacy timestamp absent");
        for(int i=0;i<5;i++)check(CountdownMath.markerTime(1000,7201000,i)==1000+i*1800000L,"tick "+i);
        try {CountdownMath.markerTime(1000,7201000,5);throw new AssertionError("tick range");}catch(IllegalArgumentException expected) {tests++;}
        System.out.println("PASS " + tests + " checks: preset selection, custom selection, countdown, progress, tick timestamps");
    }
}
