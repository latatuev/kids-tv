package ru.family.call;

/** Pure button-selection rules. Inactive timers must not leave a blue preset. */
final class SessionSelection {
    private SessionSelection() {}

    static boolean isPresetSelected(boolean active, int minutes, int preset) {
        return active && minutes == preset;
    }

    static boolean isCustomSelected(boolean active, int minutes) {
        if (!active || !SilencePolicy.validDuration(minutes)) return false;
        for (int preset : new int[]{30, 60, 120, 180, 240}) {
            if (minutes == preset) return false;
        }
        return true;
    }
}
