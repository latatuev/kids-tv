package ru.family.call;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;

/** Local self-test only. This class does not receive remote commands. */
public final class SignalPlayer {
    private volatile boolean cancelled = false;
    private AudioTrack activeTrack;
    private Thread running;

    public synchronized void stop() {
        cancelled = true;
        if (activeTrack != null) {
            try { activeTrack.pause(); activeTrack.flush(); activeTrack.release(); } catch (Exception ignored) {}
            activeTrack = null;
        }
    }
    public synchronized void play(int seconds) {
        stop();
        cancelled = false;
        running = new Thread(() -> renderSound(seconds), "family-call-signal-test");
        running.setDaemon(true);
        running.start();
    }
    private void renderSound(int seconds) {
        final int sampleRate = 16000;
        AudioTrack track = null;
        try {
            int min = AudioTrack.getMinBufferSize(sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) return;
            track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setBufferSizeInBytes(Math.max(min, 4096)).build();
            synchronized (this) {
                if (cancelled) { track.release(); return; }
                activeTrack = track;
            }
            track.setVolume(0.25f);
            track.play();
            int total = seconds * sampleRate;
            short[] samples = new short[1600];
            for (int offset = 0; offset < total && !cancelled; offset += samples.length) {
                int n = Math.min(samples.length, total - offset);
                for (int i = 0; i < n; i++) {
                    double t = (offset + i) / (double) sampleRate;
                    // 1s gentle single beep; long signal: 0.5s on / 1.5s off repeated.
                    boolean audible = seconds == 1 || (t % 2.0) < 0.5;
                    double envelope = seconds == 1 ? Math.min(1.0, Math.min(t * 30, (1 - t) * 30)) : 1.0;
                    samples[i] = (short)(audible ? Math.sin(2 * Math.PI * 740 * t) * 9000 * Math.max(0, envelope) : 0);
                }
                int written = track.write(samples, 0, n, AudioTrack.WRITE_BLOCKING);
                if (written < 0) break;
            }
        } catch (Exception ignored) {
            // A failed local test must not affect the user's ringer mode.
        } finally {
            synchronized (this) {
                if (activeTrack == track && track != null) {
                    try { track.stop(); track.release(); } catch (Exception ignored) {}
                    activeTrack = null;
                }
            }
        }
    }
}
