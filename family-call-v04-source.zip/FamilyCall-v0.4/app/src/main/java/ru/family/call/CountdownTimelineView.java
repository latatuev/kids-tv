package ru.family.call;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Five absolute clock markers and a live elapsed-time fill. */
final class CountdownTimelineView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SimpleDateFormat clock = new SimpleDateFormat("HH:mm", Locale.getDefault());
    private long startedAt;
    private long endsAt;
    private float progress;
    private final int blue = Color.rgb(46, 100, 205);
    private final int slate = Color.rgb(97, 109, 127);

    CountdownTimelineView(Context context) { super(context); }

    private float dp(float d) { return d * getResources().getDisplayMetrics().density; }
    private float sp(float s) { return s * getResources().getDisplayMetrics().scaledDensity; }

    void setSession(long start, long end, long now) {
        startedAt = start;
        endsAt = end;
        progress = CountdownMath.fractionElapsed(now, start, end);
        setContentDescription("Прогресс тишины: " + Math.round(progress * 100) + "%");
        invalidate();
    }

    @Override protected void onMeasure(int wSpec, int hSpec) {
        super.onMeasure(wSpec, MeasureSpec.makeMeasureSpec((int) dp(60), MeasureSpec.EXACTLY));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (startedAt <= 0 || endsAt <= startedAt) return;
        float start = dp(5), end = getWidth() - dp(5);
        float width = end - start;
        float cy = dp(17), half = dp(4);
        if (width <= 0) return;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xffc8d4e9);
        canvas.drawRoundRect(new RectF(start, cy - half, end, cy + half), half, half, paint);
        if (progress > 0) {
            paint.setColor(blue);
            canvas.drawRoundRect(new RectF(start, cy - half, start + width * progress,
                    cy + half), half, half, paint);
        }
        for (int i = 0; i <= 4; i++) {
            float x = start + width * i / 4f;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(1.5f));
            paint.setColor(0xff7387aa);
            canvas.drawLine(x, cy - dp(8), x, cy + dp(8), paint);

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(slate);
            paint.setTextSize(sp(10));
            paint.setTextAlign(i == 0 ? Paint.Align.LEFT :
                    i == 4 ? Paint.Align.RIGHT : Paint.Align.CENTER);
            canvas.drawText(clock.format(new Date(CountdownMath.markerTime(startedAt, endsAt, i))),
                    x, dp(45), paint);
        }
        // Distinct position marker for elapsed time, including between tick marks.
        float thumb = start + width * progress;
        paint.setColor(blue);
        canvas.drawCircle(thumb, cy, dp(5), paint);
        paint.setColor(Color.WHITE);
        canvas.drawCircle(thumb, cy, dp(2.2f), paint);
    }
}
