package ru.family.call;

import java.util.Locale;

/** Pure timer presentation calculations, no Android dependencies. */
final class CountdownMath {
    private CountdownMath() {}

    static long secondsLeft(long nowMillis, long untilMillis) {
        if (untilMillis <= nowMillis) return 0;
        return (untilMillis - nowMillis + 999L) / 1000L;
    }

    static String formatRemaining(long nowMillis, long untilMillis) {
        long seconds = secondsLeft(nowMillis, untilMillis);
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long remainderSeconds = seconds % 60;
        return String.format(Locale.ROOT, "%02d:%02d:%02d", hours, minutes, remainderSeconds);
    }

    static float fractionElapsed(long nowMillis, long startMillis, long untilMillis) {
        if (startMillis <= 0 || untilMillis <= startMillis) return 0f;
        double amount = (double) (nowMillis - startMillis) / (double) (untilMillis - startMillis);
        return (float) Math.max(0, Math.min(1, amount));
    }

    static long markerTime(long startedAt, long untilMillis, int quarter) {
        if (quarter < 0 || quarter > 4 || startedAt <= 0 || untilMillis <= startedAt) {
            throw new IllegalArgumentException("Invalid timeline or marker");
        }
        return startedAt + (untilMillis - startedAt) * quarter / 4;
    }
}
