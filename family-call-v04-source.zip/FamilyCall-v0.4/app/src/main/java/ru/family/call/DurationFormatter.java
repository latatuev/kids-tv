package ru.family.call;

/** Russian language duration preview. No Android dependencies. */
final class DurationFormatter {
    private DurationFormatter() {}

    private static String unit(int n, String one, String few, String many) {
        int lastTwo = n % 100;
        if (lastTwo >= 11 && lastTwo <= 14) return many;
        int last = n % 10;
        if (last == 1) return one;
        if (last >= 2 && last <= 4) return few;
        return many;
    }

    static String describe(int totalMinutes) {
        if (totalMinutes < 1 || totalMinutes > 1439) {
            throw new IllegalArgumentException("Duration must be 1..1439 minutes");
        }
        int h = totalMinutes / 60;
        int m = totalMinutes % 60;
        String hours = h > 0 ? h + " " + unit(h, "час", "часа", "часов") : "";
        String minutes = m > 0 ? m + " " + unit(m, "минута", "минуты", "минут") : "";
        return h > 0 && m > 0 ? hours + " " + minutes : (h > 0 ? hours : minutes);
    }
}
