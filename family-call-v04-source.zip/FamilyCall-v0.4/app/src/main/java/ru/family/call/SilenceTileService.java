package ru.family.call;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** Tap: start 30 minutes / restore sound. Long-tap opens the app. */
public class SilenceTileService extends TileService {
    @Override public void onStartListening() {
        super.onStartListening();
        updateTileState();
    }

    private void updateTileState() {
        Tile tile = getQsTile();
        if (tile == null) return;
        SilenceController controller = new SilenceController(this);
        controller.reconcile();
        tile.setState(controller.isActive() ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        tile.setLabel(controller.isActive() ? "Вернуть звук" : (controller.chosenMode() == SilenceController.MODE_VIBRATE ? "Вибро 30 мин" : controller.chosenMode() == SilenceController.MODE_DND ? "Не бесп. 30 мин" : "Тихо 30 мин"));
        if (Build.VERSION.SDK_INT >= 29) tile.setSubtitle(
                controller.isActive() ? "Таймер активен" : "Одним нажатием");
        tile.updateTile();
    }

    @Override public void onClick() {
        super.onClick();
        SilenceController controller = new SilenceController(this);
        try {
            if (controller.isActive()) controller.stop();
            else if (controller.ready()) controller.start(30);
            else { openSettingsScreen(); return; }
            updateTileState();
        } catch (Exception e) {
            // Never silently start an unreliable timer: explain errors in the activity.
            openSettingsScreen();
        }
    }

    private void openSettingsScreen() {
        Intent intent = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (Build.VERSION.SDK_INT >= 34) {
            PendingIntent pi = PendingIntent.getActivity(this, 11, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            startActivityAndCollapse(pi);
        } else {
            startActivityAndCollapse(intent);
        }
    }
}
