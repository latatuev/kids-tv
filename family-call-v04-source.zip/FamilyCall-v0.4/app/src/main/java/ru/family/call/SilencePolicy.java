package ru.family.call;

/** Pure decision rules; mode values match AudioManager constants. */
public final class SilencePolicy {
    private SilencePolicy() {}
    public static final int SILENT = 0;
    public static final int VIBRATE = 1;
    public static final int NORMAL = 2;

    /** One minute minimum; keeps a custom timer within one calendar day. */
    public static boolean validDuration(int minutes) {
        return minutes >= 1 && minutes <= (23 * 60 + 59);
    }

    public static int restoreMode(int modeBefore) {
        // Explicitly starting a timed silence while already silent means
        // "I want sound again when the timer ends".
        return modeBefore == SILENT ? NORMAL : modeBefore;
    }

    public static boolean shouldRestore(boolean active, long now, long until, int currentMode) {
        return active && until > 0 && now >= until && currentMode == SILENT;
    }

    public static boolean shouldStopWithoutRestoring(boolean active, int currentMode) {
        // If the user turned sound/vibration back on, never overwrite that choice.
        return active && currentMode != SILENT;
    }
}
