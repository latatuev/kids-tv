package ru.family.call;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Build;
import android.service.quicksettings.TileService;

/** All timers are local to the phone. No network or cloud privileges. */
public final class SilenceController {
    public static final int MODE_SILENT = 0;
    public static final int MODE_VIBRATE = 1;
    public static final int MODE_DND = 3;
    public static final String ACTION_EXPIRE = "ru.family.call.EXPIRE";
    private static final String PREFS = "silence-state";
    private static final String ACTIVE = "active", UNTIL = "until", STARTED = "started_at";
    private static final String DURATION = "duration_minutes", RESTORE = "restore_mode";
    private static final String RESTORE_DND = "restore_dnd", ACTIVE_MODE = "active_mode", CHOICE = "chosen_mode";

    private final Context context;
    private final SharedPreferences prefs;
    private final AlarmManager alarms;
    private final AudioManager audio;
    private final NotificationManager notification;

    public SilenceController(Context context) {
        this.context = context.getApplicationContext();
        prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        alarms = (AlarmManager) this.context.getSystemService(Context.ALARM_SERVICE);
        audio = (AudioManager) this.context.getSystemService(Context.AUDIO_SERVICE);
        notification = (NotificationManager) this.context.getSystemService(Context.NOTIFICATION_SERVICE);
    }
    public boolean hasPolicyAccess() { return notification.isNotificationPolicyAccessGranted(); }
    public boolean canScheduleExact() { return Build.VERSION.SDK_INT < 31 || alarms.canScheduleExactAlarms(); }
    public boolean ready() { return hasPolicyAccess() && canScheduleExact(); }
    public boolean isActive() { return prefs.getBoolean(ACTIVE, false); }
    public long until() { return prefs.getLong(UNTIL, 0); }
    public long startedAt() { return prefs.getLong(STARTED, 0); }
    public int activeDurationMinutes() { return prefs.getInt(DURATION, 0); }
    public int currentMode() { return audio.getRingerMode(); }
    public int currentDnd() { return notification.getCurrentInterruptionFilter(); }
    public int activeMode() { return prefs.getInt(ACTIVE_MODE, MODE_SILENT); } // v0.3 migration
    public int chosenMode() { return prefs.getInt(CHOICE, MODE_VIBRATE); }
    public void chooseMode(int mode) {
        if (!isValidMode(mode)) throw new IllegalArgumentException("Неизвестный режим");
        prefs.edit().putInt(CHOICE, mode).apply();
        updateTile(context);
    }
    public static boolean isValidMode(int mode) {
        return mode == MODE_SILENT || mode == MODE_VIBRATE || mode == MODE_DND;
    }
    public static String modeName(int mode) {
        if (mode == MODE_VIBRATE) return "Вибрация";
        if (mode == MODE_DND) return "Не беспокоить";
        return "Без звука";
    }

    private PendingIntent alarmIntent() {
        Intent intent = new Intent(context, AlarmReceiver.class).setAction(ACTION_EXPIRE);
        return PendingIntent.getBroadcast(context, 491, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Start or replace a session. The first session captures the user's original settings. */
    public void start(int minutes) {
        if (!SilencePolicy.validDuration(minutes)) throw new IllegalArgumentException("Выбери от 1 мин до 23 ч 59 мин.");
        if (!ready()) throw new IllegalStateException("Предоставь доступ к режиму тишины и точным таймерам.");
        int target = chosenMode();
        int originalRinger = isActive() ? prefs.getInt(RESTORE, AudioManager.RINGER_MODE_NORMAL)
                : SilencePolicy.restoreMode(audio.getRingerMode());
        int originalDnd = isActive() ? prefs.getInt(RESTORE_DND, NotificationManager.INTERRUPTION_FILTER_ALL)
                : notification.getCurrentInterruptionFilter();
        long now = System.currentTimeMillis(), end = now + minutes * 60_000L;
        int priorRinger = audio.getRingerMode();
        int priorDnd = notification.getCurrentInterruptionFilter();
        int oldMode = isActive() ? activeMode() : -1;
        try {
            alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, alarmIntent());
            // Only undo the DND setting that this app applied; preserve a pre-existing DND setting.
            if (oldMode == MODE_DND && target != MODE_DND && priorDnd == NotificationManager.INTERRUPTION_FILTER_ALARMS)
                notification.setInterruptionFilter(originalDnd);
            if (target == MODE_DND) {
                // Alarms remain enabled, while ordinary calls and notifications are muted.
                notification.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS);
            } else {
                audio.setRingerMode(target == MODE_VIBRATE
                        ? AudioManager.RINGER_MODE_VIBRATE : AudioManager.RINGER_MODE_SILENT);
                if (audio.getRingerMode() != target) throw new IllegalStateException("Android не разрешил сменить режим звука.");
            }
            if (oldMode != -1 && oldMode != MODE_DND && target == MODE_DND) {
                // Restore audible ringing immediately; DND itself suppresses interruptions.
                audio.setRingerMode(originalRinger);
            }
            if (target == MODE_DND && notification.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALARMS)
                throw new IllegalStateException("Android не разрешил включить «Не беспокоить».");
            if (!prefs.edit().putBoolean(ACTIVE, true).putLong(UNTIL, end)
                    .putLong(STARTED, now).putInt(DURATION, minutes)
                    .putInt(RESTORE, originalRinger).putInt(RESTORE_DND, originalDnd)
                    .putInt(ACTIVE_MODE, target).commit()) throw new IllegalStateException("Не удалось сохранить таймер.");
            updateTile(context);
        } catch (Exception e) {
            alarms.cancel(alarmIntent());
            try { if (audio.getRingerMode() != priorRinger) audio.setRingerMode(priorRinger); }
            catch (Exception ignored) {}
            try { if (notification.getCurrentInterruptionFilter() != priorDnd)
                notification.setInterruptionFilter(priorDnd); }
            catch (Exception ignored) {}
            throw new IllegalStateException("Не удалось включить режим: " + e.getMessage(), e);
        }
    }

    /** User-invoked cancellation. Do not override changes made after session started. */
    public void stop() {
        if (!isActive()) return;
        restoreCurrentIfStillOurs();
        clearState();
    }
    private void restoreCurrentIfStillOurs() {
        int mode = activeMode();
        if (mode == MODE_DND) {
            if (notification.getCurrentInterruptionFilter() == NotificationManager.INTERRUPTION_FILTER_ALARMS)
                notification.setInterruptionFilter(prefs.getInt(RESTORE_DND, NotificationManager.INTERRUPTION_FILTER_ALL));
        } else if (audio.getRingerMode() == mode) {
            audio.setRingerMode(prefs.getInt(RESTORE, AudioManager.RINGER_MODE_NORMAL));
        }
    }
    private boolean manuallyChanged() {
        if (activeMode() == MODE_DND)
            return notification.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALARMS;
        return audio.getRingerMode() != activeMode();
    }
    private void clearState() {
        alarms.cancel(alarmIntent());
        prefs.edit().putBoolean(ACTIVE, false).remove(UNTIL).remove(STARTED).remove(DURATION)
                .remove(RESTORE).remove(RESTORE_DND).remove(ACTIVE_MODE).commit();
        updateTile(context);
    }
    public void reconcile() {
        if (!isActive()) return;
        if (System.currentTimeMillis() >= until()) {
            try { restoreCurrentIfStillOurs(); }
            catch (SecurityException e) { return; } // Retain session until permission is restored
            clearState();
        } else if (manuallyChanged()) clearState();
    }
    public void restoreAlarmAfterBootOrPermission() {
        if (!isActive()) return;
        if (System.currentTimeMillis() >= until()) { reconcile(); return; }
        if (canScheduleExact()) {
            try { alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, until(), alarmIntent()); }
            catch (SecurityException ignored) {}
        }
        updateTile(context);
    }
    public static void updateTile(Context context) {
        TileService.requestListeningState(context, new ComponentName(context, SilenceTileService.class));
    }
}
