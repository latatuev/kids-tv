package ru.family.call;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (SilenceController.ACTION_EXPIRE.equals(intent.getAction())) {
            new SilenceController(context).reconcile();
        }
    }
}
