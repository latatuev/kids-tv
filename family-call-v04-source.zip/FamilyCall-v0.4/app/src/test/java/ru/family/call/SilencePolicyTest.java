package ru.family.call;

import org.junit.Test;
import static org.junit.Assert.*;

public class SilencePolicyTest {
    @Test public void acceptsAllPresets() {
        for (int n : new int[]{30, 60, 120, 180, 240}) assertTrue(SilencePolicy.validDuration(n));
    }
    @Test public void acceptsCustomMinutesAndLongerSleep() {
        for (int n : new int[]{1, 45, 75, 240, 480, 1439}) assertTrue(SilencePolicy.validDuration(n));
    }
    @Test public void refusesInvalidDurations() {
        for (int n : new int[]{-1, 0, 1440, 5000}) assertFalse(SilencePolicy.validDuration(n));
    }
    @Test public void restoresNormalWhenTimedFromSilent() {
        assertEquals(SilencePolicy.NORMAL, SilencePolicy.restoreMode(SilencePolicy.SILENT));
    }
    @Test public void preservesVibration() {
        assertEquals(SilencePolicy.VIBRATE, SilencePolicy.restoreMode(SilencePolicy.VIBRATE));
    }
    @Test public void neverRestoresBeforeDeadline() {
        assertFalse(SilencePolicy.shouldRestore(true, 9_999, 10_000, SilencePolicy.SILENT));
    }
    @Test public void restoresAtDeadlineWhenStillSilent() {
        assertTrue(SilencePolicy.shouldRestore(true, 10_000, 10_000, SilencePolicy.SILENT));
    }
    @Test public void manualSoundChangePreventsOverride() {
        assertFalse(SilencePolicy.shouldRestore(true, 11_000, 10_000, SilencePolicy.NORMAL));
        assertTrue(SilencePolicy.shouldStopWithoutRestoring(true, SilencePolicy.NORMAL));
    }
    @Test public void inactiveTimerNeverChangesSound() {
        assertFalse(SilencePolicy.shouldRestore(false, 11_000, 10_000, SilencePolicy.SILENT));
    }
}
