package ru.family.call;

import org.junit.Test;
import static org.junit.Assert.*;

public class SessionSelectionTest {
    @Test public void twoHoursDoesNotHighlightThirtyMinutes() {
        assertFalse(SessionSelection.isPresetSelected(true, 120, 30));
        assertTrue(SessionSelection.isPresetSelected(true, 120, 120));
    }
    @Test public void inactiveDoesNotHighlightAnyPreset() {
        assertFalse(SessionSelection.isPresetSelected(false, 30, 30));
        assertFalse(SessionSelection.isCustomSelected(false, 75));
    }
    @Test public void customDurationIsHighlightedOnlyWhenActive() {
        assertTrue(SessionSelection.isCustomSelected(true, 75));
        assertTrue(SessionSelection.isCustomSelected(true, 480));
        assertFalse(SessionSelection.isCustomSelected(true, 30));
        assertFalse(SessionSelection.isCustomSelected(true, 120));
    }
    @Test public void legacySessionWithoutDurationIsNotFalselySelected() {
        assertFalse(SessionSelection.isCustomSelected(true, 0));
        assertFalse(SessionSelection.isPresetSelected(true, 0, 30));
    }
}
