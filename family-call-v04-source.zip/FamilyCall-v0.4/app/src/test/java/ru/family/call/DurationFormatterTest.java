package ru.family.call;

import org.junit.Test;
import static org.junit.Assert.*;

public class DurationFormatterTest {
    @Test public void minutes() {
        assertEquals("1 минута", DurationFormatter.describe(1));
        assertEquals("2 минуты", DurationFormatter.describe(2));
        assertEquals("11 минут", DurationFormatter.describe(11));
        assertEquals("21 минута", DurationFormatter.describe(21));
        assertEquals("45 минут", DurationFormatter.describe(45));
    }
    @Test public void hours() {
        assertEquals("1 час", DurationFormatter.describe(60));
        assertEquals("2 часа", DurationFormatter.describe(120));
        assertEquals("4 часа", DurationFormatter.describe(240));
        assertEquals("5 часов", DurationFormatter.describe(300));
    }
    @Test public void mixed() {
        assertEquals("1 час 1 минута", DurationFormatter.describe(61));
        assertEquals("2 часа 22 минуты", DurationFormatter.describe(142));
        assertEquals("23 часа 59 минут", DurationFormatter.describe(1439));
    }
    @Test public void rejectsInvalidDuration() {
        for (int n: new int[]{0,-1,1440}) {
            try {
                DurationFormatter.describe(n);
                fail("Expected invalid duration " + n);
            } catch (IllegalArgumentException expected) {
                // expected
            }
        }
    }
}
