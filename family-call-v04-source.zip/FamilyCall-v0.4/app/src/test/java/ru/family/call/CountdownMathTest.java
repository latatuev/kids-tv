package ru.family.call;

import org.junit.Test;
import static org.junit.Assert.*;

public class CountdownMathTest {
    @Test public void countdownRoundsUpToNextSecond() {
        assertEquals("02:00:00", CountdownMath.formatRemaining(1000, 7201000));
        assertEquals("01:59:59", CountdownMath.formatRemaining(2000, 7201000));
        assertEquals("00:00:01", CountdownMath.formatRemaining(5001, 6000));
        assertEquals("00:00:00", CountdownMath.formatRemaining(6000, 6000));
    }
    @Test public void elapsedFractionIsClamped() {
        assertEquals(0f, CountdownMath.fractionElapsed(0, 100, 900), 0.0001f);
        assertEquals(0.5f, CountdownMath.fractionElapsed(500, 100, 900), 0.0001f);
        assertEquals(1f, CountdownMath.fractionElapsed(999, 100, 900), 0.0001f);
        assertEquals(0f, CountdownMath.fractionElapsed(50, 0, 900), 0.0001f);
    }
    @Test public void markerTimesAreEquallySpaced() {
        assertEquals(1000, CountdownMath.markerTime(1000, 7201000, 0));
        assertEquals(1801000, CountdownMath.markerTime(1000, 7201000, 1));
        assertEquals(3601000, CountdownMath.markerTime(1000, 7201000, 2));
        assertEquals(5401000, CountdownMath.markerTime(1000, 7201000, 3));
        assertEquals(7201000, CountdownMath.markerTime(1000, 7201000, 4));
    }
    @Test(expected=IllegalArgumentException.class)
    public void rejectsOutOfRangeMarker() { CountdownMath.markerTime(1000, 3000, 5); }
}
