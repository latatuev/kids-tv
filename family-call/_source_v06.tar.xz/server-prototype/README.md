# Family Call — secure remote signal relay (development prototype)

## Verified

- New devices get independent random bearer credentials (token digest is held in the dev database).
- Consent-based one-time pairing codes (8 decimal digits, 3-minute expiry, consumed once).
- Only paired devices can queue and retrieve a remote signal.
- Parameters: short/long, 1–30 seconds, 0–100 relative playback volume.
- Signals expire after 15 seconds. Additional signal limited to one every 15 seconds.
- Only intended receiver can acknowledge `played` or `failed`; only sender can read status.
- Unit/integration tests: `cd backend && python -m pytest -q`.

## Not implemented / not proven

- **NOT DEPLOYED.** The code is a local FastAPI prototype with SQLite. `/tmp` is not safe durable multi-instance storage for Yandex Cloud Functions.
- **NO Firebase Cloud Messaging integration.** This HTTP pull model alone cannot wake a background Android app reliably.
- **NO Android client using this protocol.** v0.5 app only has a local sound preview.
- No production authentication provisioning, server-side token revocation, anti-brute-force pair-code throttling, telemetry, or production database yet.
- Server acknowledgment is supplied by client; `played` cannot prove sound was physically audible.
- Audio at `USAGE_ALARM` and Do Not Disturb override remain device-specific and need Samsung physical tests.

## Recommended production architecture

Android application (each spouse) -> HTTPS Yandex Cloud API Gateway -> authenticated Cloud Function -> YDB device and signal records -> FCM high-priority data push -> Android `FirebaseMessagingService` -> short-lived playback and acknowledgment.

The backend owns FCM service credentials, device-to-device access control, replay prevention, TTL and rate limits. Phone stores its device credential in Android Keystore-protected storage and rotates/revokes on unpair. Sender obtains delivery/processing states, not a false claim of audibility.

## Deployment prerequisites

1. Authorized Yandex Cloud API permissions for API Gateway / Cloud Functions / YDB and the target folder.
2. A Firebase project configured with FCM for the final Android package ID and service-account access held only by the backend.
3. Production Android signing identity (or explicit reinstall migration plan).
4. Recipient opt-in and testing of on-device permission and DND playback behavior.

Do not put service keys in source control or an Android APK. Do not treat the prototype as an Internet-exposed production API.
