"""Development-only relay prototype. Not a production Yandex Cloud deployment.

Security properties: 32-byte random device tokens, hashed at rest; invite consent;
recipient-only fetch/ack; expiry and rate limiting; bounded parameters.
Production requires TLS, managed persistent DB, authentication hardening,
rate limits across replicas, push delivery, rotation, audit and monitoring.
"""
import os
import re
import time
import hmac
import json
import sqlite3
import hashlib
import secrets
from contextlib import contextmanager
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

DB = os.environ.get('FAMILY_CALL_DB', '/tmp/family_call_dev.sqlite3')
app = FastAPI(title='Family Call relay - DEVELOPMENT ONLY')
KINDS = {'short', 'long'}

@contextmanager
def db():
    c = sqlite3.connect(DB, timeout=5, isolation_level=None)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA busy_timeout=5000')
    c.execute('PRAGMA journal_mode=WAL')
    c.executescript('''
    CREATE TABLE IF NOT EXISTS devices (
      id TEXT PRIMARY KEY, token_hash TEXT NOT NULL, label TEXT NOT NULL,
      peer TEXT, created INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS pair_attempts (
      device TEXT NOT NULL, created INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS pair_attempts_device ON pair_attempts(device,created);
    CREATE TABLE IF NOT EXISTS invites (
      code_hash TEXT PRIMARY KEY, owner TEXT NOT NULL, expires INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS signals (
      id TEXT PRIMARY KEY, sender TEXT NOT NULL, recipient TEXT NOT NULL,
      kind TEXT NOT NULL, seconds INTEGER NOT NULL, volume INTEGER NOT NULL,
      created INTEGER NOT NULL, expires INTEGER NOT NULL, state TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS signals_recipient ON signals(recipient,state,expires);
    ''')
    try: yield c
    finally: c.close()

def digest(s): return hashlib.sha256(s.encode()).hexdigest()

def auth(device_id, authorization, conn):
    if not authorization or not authorization.startswith('Bearer '):
        raise HTTPException(401, 'Device token required')
    row=conn.execute('SELECT * FROM devices WHERE id=?',(device_id,)).fetchone()
    if not row or not hmac.compare_digest(row['token_hash'],digest(authorization[7:])):
        raise HTTPException(401,'Invalid device token')
    return row

class Registration(BaseModel):
    label: str = Field(min_length=1,max_length=32)

class Accept(BaseModel):
    code: str = Field(pattern=r'^[0-9]{8}$')

class Signal(BaseModel):
    kind: str
    seconds: int = Field(ge=1,le=30)
    volume: int = Field(ge=0,le=100)

class Ack(BaseModel):
    state: str

@app.post('/v1/devices')
def register(body: Registration):
    device_id=secrets.token_urlsafe(16)
    token=secrets.token_urlsafe(32)
    with db() as c:
        c.execute('INSERT INTO devices VALUES (?,?,?,?,?)',(device_id,digest(token),body.label,None,int(time.time())))
    return {'device_id':device_id,'token':token}

@app.post('/v1/devices/{device_id}/invites')
def invite(device_id:str,authorization:str|None=Header(None)):
    now=int(time.time())
    with db() as c:
        auth(device_id,authorization,c)
        c.execute('DELETE FROM invites WHERE expires<? OR owner=?',(now,device_id))
        code=f'{secrets.randbelow(100_000_000):08d}'
        c.execute('INSERT INTO invites VALUES (?,?,?)',(digest(code),device_id,now+180))
    return {'code':code,'expires_in_seconds':180}

@app.post('/v1/devices/{device_id}/pair')
def pair(device_id:str,body:Accept,authorization:str|None=Header(None)):
    now=int(time.time())
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        receiver=auth(device_id,authorization,c)
        c.execute('DELETE FROM pair_attempts WHERE created<=?',(now-300,))
        failures=c.execute('SELECT COUNT(*) FROM pair_attempts WHERE device=? AND created>?',
                           (device_id,now-300)).fetchone()[0]
        if failures>=5:
            raise HTTPException(429,'Pairing temporarily rate limited')
        ticket=c.execute('SELECT * FROM invites WHERE code_hash=?',(digest(body.code),)).fetchone()
        if not ticket or ticket['expires']<now or ticket['owner']==device_id:
            c.execute('INSERT INTO pair_attempts VALUES (?,?)',(device_id,now))
            c.execute('COMMIT')
            raise HTTPException(400,'Invalid or expired pairing code')
        sender=c.execute('SELECT * FROM devices WHERE id=?',(ticket['owner'],)).fetchone()
        if receiver['peer'] is not None or sender['peer'] is not None:
            raise HTTPException(409,'One device is already paired')
        c.execute('UPDATE devices SET peer=? WHERE id=?',(device_id,ticket['owner']))
        c.execute('UPDATE devices SET peer=? WHERE id=?',(ticket['owner'],device_id))
        c.execute('DELETE FROM invites WHERE code_hash=?',(digest(body.code),))
        c.execute('DELETE FROM pair_attempts WHERE device=?',(device_id,))
        c.execute('COMMIT')
    return {'paired':True}

@app.post('/v1/devices/{device_id}/signals')
def send(device_id:str,body:Signal,authorization:str|None=Header(None)):
    now=int(time.time())
    if body.kind not in KINDS:
        raise HTTPException(422,'Unsupported signal kind')
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        caller=auth(device_id,authorization,c)
        if not caller['peer']:
            raise HTTPException(409,'Pair devices first')
        # Avoid alerts storms: no more than one accepted signal per 15 seconds.
        last=c.execute('SELECT MAX(created) AS last FROM signals WHERE sender=?',(device_id,)).fetchone()['last']
        if last is not None and now-last<15:
            raise HTTPException(429,'Wait before another signal')
        signal_id=secrets.token_urlsafe(16)
        c.execute('INSERT INTO signals VALUES (?,?,?,?,?,?,?,?,?)',
                  (signal_id,device_id,caller['peer'],body.kind,body.seconds,body.volume,now,now+15,'pending'))
        c.execute('COMMIT')
    return {'id':signal_id,'state':'queued','expires_at':now+15}

@app.get('/v1/devices/{device_id}/signals')
def inbox(device_id:str,authorization:str|None=Header(None)):
    now=int(time.time())
    with db() as c:
        auth(device_id,authorization,c)
        c.execute('UPDATE signals SET state="expired" WHERE state="pending" AND expires<=?',(now,))
        rows=c.execute('SELECT id,kind,seconds,volume,expires FROM signals WHERE recipient=? AND state="pending" AND expires>? ORDER BY created LIMIT 5',(device_id,now)).fetchall()
    return {'signals':[dict(r) for r in rows]}

@app.post('/v1/devices/{device_id}/signals/{signal_id}/ack')
def acknowledge(device_id:str,signal_id:str,body:Ack,authorization:str|None=Header(None)):
    if body.state not in {'played','failed'}:
        raise HTTPException(422,'Invalid ack state')
    with db() as c:
        auth(device_id,authorization,c)
        row=c.execute('SELECT * FROM signals WHERE id=? AND recipient=?',(signal_id,device_id)).fetchone()
        if not row: raise HTTPException(404,'Signal not found')
        if row['state']=='pending':
            if row['expires']<=int(time.time()):
                raise HTTPException(410,'Expired signal')
            c.execute('UPDATE signals SET state=? WHERE id=?',(body.state,signal_id))
        elif row['state']!=body.state:
            raise HTTPException(409,'Signal already resolved')
    return {'state':body.state}

@app.get('/v1/devices/{device_id}/signals/{signal_id}/status')
def status(device_id:str,signal_id:str,authorization:str|None=Header(None)):
    with db() as c:
        auth(device_id,authorization,c)
        row=c.execute('SELECT * FROM signals WHERE id=? AND sender=?',(signal_id,device_id)).fetchone()
        if not row:raise HTTPException(404,'Signal not found')
        state=row['state']
        if state=='pending' and row['expires']<=int(time.time()): state='expired'
    return {'state':state}
