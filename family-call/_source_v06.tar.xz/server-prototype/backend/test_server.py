import os
import tempfile
import importlib
import pytest
from fastapi.testclient import TestClient

@pytest.fixture
def api(monkeypatch,tmp_path):
    monkeypatch.setenv('FAMILY_CALL_DB',str(tmp_path/'test.sqlite'))
    import server
    monkeypatch.setattr(server,'DB',str(tmp_path/'test.sqlite'))
    return TestClient(server.app)

def create(api,name):
    r=api.post('/v1/devices',json={'label':name})
    assert r.status_code==200,r.text
    d=r.json()
    return d,{'Authorization':'Bearer '+d['token']}

def test_consent_and_ack(api):
    a,ha=create(api,'А');b,hb=create(api,'Б');c,hc=create(api,'В')
    x=api.post(f"/v1/devices/{a['device_id']}/signals",headers=ha,json={'kind':'short','seconds':1,'volume':35})
    assert x.status_code==409
    invite=api.post(f"/v1/devices/{a['device_id']}/invites",headers=ha).json()['code']
    assert api.post(f"/v1/devices/{b['device_id']}/pair",headers=hb,json={'code':invite}).status_code==200
    assert api.post(f"/v1/devices/{c['device_id']}/pair",headers=hc,json={'code':invite}).status_code==400
    sent=api.post(f"/v1/devices/{a['device_id']}/signals",headers=ha,json={'kind':'short','seconds':1,'volume':35})
    assert sent.status_code==200,sent.text
    ident=sent.json()['id']
    assert api.get(f"/v1/devices/{c['device_id']}/signals",headers=hc).json()['signals']==[]
    assert api.get(f"/v1/devices/{b['device_id']}/signals",headers=hb).json()['signals'][0]['id']==ident
    assert api.post(f"/v1/devices/{c['device_id']}/signals/{ident}/ack",headers=hc,json={'state':'played'}).status_code==404
    assert api.post(f"/v1/devices/{b['device_id']}/signals/{ident}/ack",headers=hb,json={'state':'played'}).status_code==200
    assert api.get(f"/v1/devices/{a['device_id']}/signals/{ident}/status",headers=ha).json()['state']=='played'
    assert api.post(f"/v1/devices/{a['device_id']}/signals",headers=ha,json={'kind':'long','seconds':15,'volume':55}).status_code==429

def test_auth_and_validation(api):
    a,h=create(api,'А')
    path=f"/v1/devices/{a['device_id']}/invites"
    assert api.post(path).status_code==401
    assert api.post(path,headers={'Authorization':'Bearer nope'}).status_code==401
    assert api.post(path,headers=h).status_code==200
    b,hb=create(api,'Б')
    assert api.post(f"/v1/devices/{b['device_id']}/pair",headers=hb,json={'code':'00000000'}).status_code==400
    assert api.post(f"/v1/devices/{a['device_id']}/signals",headers=h,json={'kind':'short','seconds':999,'volume':30}).status_code==422


def test_pairing_attempts_rate_limited(api):
    owner, auth_owner=create(api,'Owner')
    guest, auth_guest=create(api,'Guest')
    url=f"/v1/devices/{guest['device_id']}/pair"
    for i in range(5):
        result=api.post(url,headers=auth_guest,json={'code':f'{i:08d}'})
        assert result.status_code==400,result.text
    invite=api.post(f"/v1/devices/{owner['device_id']}/invites",headers=auth_owner).json()['code']
    result=api.post(url,headers=auth_guest,json={'code':invite})
    assert result.status_code==429,result.text

def test_second_device_cannot_take_existing_pair(api):
    a,ha=create(api,'A');b,hb=create(api,'B');c,hc=create(api,'C')
    code=api.post(f"/v1/devices/{a['device_id']}/invites",headers=ha).json()['code']
    assert api.post(f"/v1/devices/{b['device_id']}/pair",headers=hb,json={'code':code}).status_code==200
    other=api.post(f"/v1/devices/{c['device_id']}/invites",headers=hc).json()['code']
    assert api.post(f"/v1/devices/{a['device_id']}/pair",headers=ha,json={'code':other}).status_code==409
