package ru.family.call;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.Window;
import android.view.WindowManager;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.EditText;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.DateFormat;
import java.util.Date;

/** Small native utility: no network and no sharing of privileges with other apps. */
public class MainActivity extends Activity {
    private final int BLACK = Color.rgb(25, 33, 47);
    private final int BLUE = Color.rgb(46, 100, 205);
    private final int GRAY = Color.rgb(97, 109, 127);
    private final int WHITE = Color.WHITE;
    private SilenceController controller;
    private final SignalPlayer signalPlayer = new SignalPlayer();
    private RelayClient relay;
    private LinearLayout content;
    private TextView status;
    private TextView permissions;
    private TextView countdown;
    private CountdownTimelineView timeline;
    private final Handler ticker = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (controller == null || !controller.isActive()) return;
            controller.reconcile();
            if (!controller.isActive()) { render(); return; }
            updateCountdown();
            ticker.postDelayed(this, 1000L);
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        controller = new SilenceController(this);
        relay = new RelayClient(this);
        render();
    }
    @Override protected void onResume() {
        super.onResume();
        if (controller != null) render();
    }
    @Override protected void onPause() {
        ticker.removeCallbacks(tick);
        signalPlayer.stop();
        super.onPause();
    }
    /** Configuration preview. No command is transmitted to another device. */
    private void showRemoteSignalSettings() {
        Dialog dialog = new Dialog(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(20), dp(20), dp(20));
        panel.setBackground(bg(WHITE, 18));

        TextView title = text("Позвать Алису", 23, BLACK, true);
        panel.addView(title);
        TextView notice = text("Отправка доступна только после настройки собственного HTTPS-сервера. Автоматический приём в фоне пока не работает.", 14, GRAY, false);
        LinearLayout.LayoutParams noticeParams = new LinearLayout.LayoutParams(-1, -2);
        noticeParams.topMargin = dp(8);
        noticeParams.bottomMargin = dp(14);
        panel.addView(notice, noticeParams);

        panel.addView(text("Вид сигнала", 17, BLACK, true));
        Spinner kind = new Spinner(this);
        kind.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Короткий", "Длинный"}));
        panel.addView(kind);
        panel.addView(text("Длительность", 17, BLACK, true));
        Spinner duration = new Spinner(this);
        final int[] seconds = {1, 2, 5, 10, 15};
        duration.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"1 секунда", "2 секунды", "5 секунд", "10 секунд", "15 секунд"}));
        panel.addView(duration);
        kind.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
            public void onItemSelected(android.widget.AdapterView<?> parent, View v, int pos, long id) {
                duration.setSelection(pos == 0 ? 0 : 4);
            }
        });
        panel.addView(text("Громкость сигнала", 17, BLACK, true));
        SeekBar loudness = new SeekBar(this);
        loudness.setMax(100);
        loudness.setProgress(25);
        panel.addView(loudness);
        panel.addView(text("Фактическая громкость ограничена настройками Android и аудиовыходом.", 12, GRAY, false));
        Button preview = button("▶ Проверить на своём телефоне", false,
                () -> signalPlayer.play(seconds[duration.getSelectedItemPosition()],
                        loudness.getProgress() / 100f));
        panel.addView(preview);
        Button send = button(relay.registered() ? "Отправить сигнал" : "Отправить — сначала привяжите телефон", false,
                () -> relay.send(kind.getSelectedItemPosition() == 1, seconds[duration.getSelectedItemPosition()],
                        loudness.getProgress(), (data, error) -> runOnUiThread(() -> {
                            new android.app.AlertDialog.Builder(this)
                              .setTitle(error == null ? "Запрос поставлен в очередь" : "Не отправлено")
                              .setMessage(error == null ? "Сигнал ожидает получения; это не подтверждение звука. ID: " + data.optString("id") : error.getMessage())
                              .setPositiveButton("OK", null).show();
                        })));
        send.setEnabled(relay.registered());
        panel.addView(send);
        panel.addView(button("Остановить звук", false, signalPlayer::stop));
        panel.addView(button("Закрыть", false, dialog::dismiss));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(panel);
        dialog.setContentView(scroll);
        dialog.setOnDismissListener(d -> signalPlayer.stop());
        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) window.setLayout(-1, -2);
    }

    private EditText input(LinearLayout panel, String hint, String initial) {
        EditText field = new EditText(this);
        field.setHint(hint); field.setSingleLine(true); field.setText(initial);
        panel.addView(field, new LinearLayout.LayoutParams(-1, dp(55)));
        return field;
    }
    private void showResult(String heading, String message) {
        new android.app.AlertDialog.Builder(this).setTitle(heading).setMessage(message)
                .setPositiveButton("OK", null).show();
    }
    private void checkIncomingSignals() {
        if (!relay.registered()) { showResult("Нет регистрации", "Сначала настройте телефон и привяжите пару."); return; }
        relay.inbox((data, error) -> runOnUiThread(() -> {
            if (error != null) { showResult("Приём не выполнен", error.getMessage()); return; }
            JSONArray list = data.optJSONArray("signals");
            if (list == null || list.length() == 0) { showResult("Входящие", "Нет свежих сигналов"); return; }
            JSONObject signal = list.optJSONObject(0);
            if (signal == null) return;
            String id = signal.optString("id", "");
            int seconds = signal.optInt("seconds", 0), volume = signal.optInt("volume", -1);
            long expires = signal.optLong("expires", 0);
            if (seconds < 1 || seconds > 30 || volume < 0 || volume > 100
                    || expires <= System.currentTimeMillis()/1000L) {
                showResult("Входящие", "Некорректный или просроченный сигнал");
                return;
            }
            // Acknowledgment means the playback request was accepted, not that sound was audible.
            signalPlayer.play(seconds, volume/100f);
            relay.ack(id, true, (reply, ackError) -> runOnUiThread(() -> {
                if (ackError != null) showResult("Подтверждение не удалось", ackError.getMessage());
                else showResult("Запущен звук", seconds + " сек.; громкость " + volume +
                        "%. Воспроизведение ещё не проверено на слух.");
            }));
        }));
    }
    private void showPairingSettings() {
        Dialog d = new Dialog(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setPadding(dp(20),dp(18),dp(20),dp(18));
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(bg(WHITE, 18));
        panel.addView(text("Тестовая связь телефонов", 22, BLACK, true));
        panel.addView(text("Нужен работающий HTTPS-сервер, который вы контролируете. Сейчас он не развёрнут.",14,GRAY,false));
        EditText server = input(panel, "https://api.example.ru", relay.endpoint());
        EditText name = input(panel, "Имя устройства", "Мой телефон");
        EditText code = input(panel, "Код второго телефона: 8 цифр", "");
        panel.addView(button("Сохранить адрес", false, () -> {
            try { relay.setEndpoint(server.getText().toString()); showResult("Сохранено", "Адрес HTTPS сохранён"); }
            catch(Exception e) { showResult("Ошибка", e.getMessage()); }
        }));
        panel.addView(button("Зарегистрировать этот телефон", false, () ->
          relay.register(name.getText().toString(), (data,error) -> runOnUiThread(() ->
             showResult(error==null?"Устройство зарегистрировано":"Ошибка", error==null?
                 "ID: "+data.optString("device_id")+". Токен сохранён локально.":error.getMessage())))));
        panel.addView(button("Получить код для Алисы", false, () -> {
            try { relay.invite((data,error) -> runOnUiThread(() ->
                showResult(error==null?"Код действует 3 минуты":"Ошибка",error==null?
                data.optString("code"):error.getMessage()))); }
            catch(Exception e) {showResult("Ошибка", e.getMessage());}
        }));
        panel.addView(button("Привязаться по коду", false, () -> {
            try { relay.pair(code.getText().toString(), (data,error) -> runOnUiThread(() ->
                showResult(error==null?"Связь установлена":"Ошибка",error==null?
                "Два устройства связаны":error.getMessage()))); }
            catch(Exception e) {showResult("Ошибка",e.getMessage());}
        }));
        panel.addView(button("Закрыть", false, d::dismiss));
        ScrollView sv = new ScrollView(this); sv.addView(panel); d.setContentView(sv); d.show();
        Window w=d.getWindow(); if(w!=null)w.setLayout(-1,-2);
    }

    private void updateCountdown() {
        if (countdown == null || controller == null || !controller.isActive()) return;
        long now = System.currentTimeMillis();
        countdown.setText(CountdownMath.formatRemaining(now, controller.until()));
        if (timeline != null) {
            timeline.setSession(controller.startedAt(), controller.until(), now);
        }
    }

    private int dp(int value) { return Math.round(getResources().getDisplayMetrics().density * value); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }
    private TextView text(String value, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        return v;
    }
    private void add(TextView view, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(bottom);
        content.addView(view, p);
    }
    private Button button(String label, boolean primary, Runnable onClick) {
        Button v = new Button(this);
        v.setText(label);
        v.setAllCaps(false);
        v.setTextSize(16);
        v.setTextColor(primary ? WHITE : BLUE);
        v.setBackground(bg(primary ? BLUE : 0xffe9effc, 14));
        v.setPadding(dp(8), dp(12), dp(8), dp(12));
        v.setOnClickListener(w -> onClick.run());
        return v;
    }
    private void error(String message) {
        new android.app.AlertDialog.Builder(this)
                .setTitle("Не удалось выполнить")
                .setMessage(message).setPositiveButton("Понятно", null).show();
    }
    private void attempt(Runnable operation) {
        try { operation.run(); render(); }
        catch (Exception e) { error(e.getMessage()); render(); }
    }
    private void openPolicyAccess() {
        startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
    }
    private void openAlarmsAccess() {
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                        .setData(android.net.Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } catch (Exception e) { error("Открой настройки приложения → Будильники и напоминания."); }
        }
    }
    /** Bottom-sheet time wheels: swipe to choose, no keyboard and no network. */
    private void chooseDuration() {
        Dialog sheet = new Dialog(this);
        sheet.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(22), dp(12), dp(22), dp(24));
        GradientDrawable background = new GradientDrawable();
        background.setColor(WHITE);
        float top = dp(28);
        background.setCornerRadii(new float[]{top, top, top, top, 0, 0, 0, 0});
        panel.setBackground(background);

        View grabber = new View(this);
        grabber.setBackground(bg(0xffd9e1ee, 4));
        LinearLayout.LayoutParams gripParams = new LinearLayout.LayoutParams(dp(42), dp(5));
        gripParams.gravity = Gravity.CENTER_HORIZONTAL;
        gripParams.bottomMargin = dp(21);
        panel.addView(grabber, gripParams);

        TextView title = text("Своя длительность", 23, BLACK, true);
        panel.addView(title);
        TextView hint = text("Прокручивай колёса вверх или вниз", 14, GRAY, false);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(-1, -2);
        hintParams.topMargin = dp(5);
        hintParams.bottomMargin = dp(22);
        panel.addView(hint, hintParams);

        // The standard Android wheels support fling and finger dragging.
        // Blocking child focus avoids opening a keyboard on number taps.
        final NumberPicker hours = new NumberPicker(this);
        hours.setMinValue(0);
        hours.setMaxValue(23);
        hours.setValue(0);
        hours.setWrapSelectorWheel(false);
        hours.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        hours.setContentDescription("Часы, прокрутка для выбора");
        final NumberPicker minutes = new NumberPicker(this);
        minutes.setMinValue(0);
        minutes.setMaxValue(59);
        minutes.setValue(30);
        minutes.setWrapSelectorWheel(true);
        minutes.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        minutes.setContentDescription("Минуты, прокрутка для выбора");

        LinearLayout wheels = new LinearLayout(this);
        wheels.setGravity(Gravity.CENTER);
        wheels.setOrientation(LinearLayout.HORIZONTAL);
        wheels.setBackground(bg(0xfff3f6fc, 20));
        wheels.setPadding(dp(12), dp(9), dp(12), dp(9));

        LinearLayout hoursCol = new LinearLayout(this);
        hoursCol.setOrientation(LinearLayout.VERTICAL);
        hoursCol.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView hoursLabel = text("Часы", 14, GRAY, false);
        hoursLabel.setGravity(Gravity.CENTER);
        hoursCol.addView(hoursLabel);
        hoursCol.addView(hours, new LinearLayout.LayoutParams(-1, dp(174)));

        LinearLayout minutesCol = new LinearLayout(this);
        minutesCol.setOrientation(LinearLayout.VERTICAL);
        minutesCol.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView minutesLabel = text("Минуты", 14, GRAY, false);
        minutesLabel.setGravity(Gravity.CENTER);
        minutesCol.addView(minutesLabel);
        minutesCol.addView(minutes, new LinearLayout.LayoutParams(-1, dp(174)));

        wheels.addView(hoursCol, new LinearLayout.LayoutParams(0, -2, 1f));
        wheels.addView(minutesCol, new LinearLayout.LayoutParams(0, -2, 1f));
        panel.addView(wheels);

        TextView duration = text("", 21, BLACK, true);
        duration.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams durationParams = new LinearLayout.LayoutParams(-1, -2);
        durationParams.topMargin = dp(19);
        panel.addView(duration, durationParams);

        TextView endTime = text("", 14, GRAY, false);
        endTime.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams endParams = new LinearLayout.LayoutParams(-1, -2);
        endParams.topMargin = dp(5);
        endParams.bottomMargin = dp(22);
        panel.addView(endTime, endParams);

        Button confirm = button("Включить: " + SilenceController.modeName(controller.chosenMode()), true, () -> {
            int selected = hours.getValue() * 60 + minutes.getValue();
            if (!SilencePolicy.validDuration(selected)) {
                error("Выбери длительность от 1 минуты до 23 часов 59 минут.");
                return;
            }
            sheet.dismiss();
            attempt(() -> controller.start(selected));
        });
        Runnable refresh = () -> {
            int selected = hours.getValue() * 60 + minutes.getValue();
            boolean valid = SilencePolicy.validDuration(selected);
            duration.setText(valid ? DurationFormatter.describe(selected) : "Выбери хотя бы 1 минуту");
            String time = DateFormat.getTimeInstance(DateFormat.SHORT)
                    .format(new Date(System.currentTimeMillis() + selected * 60_000L));
            endTime.setText(valid ? "Режим закончится в " + time : "");
            confirm.setEnabled(valid);
            confirm.setAlpha(valid ? 1f : 0.4f);
        };
        NumberPicker.OnValueChangeListener changed = (picker, oldValue, newValue) -> {
            picker.performHapticFeedback(Build.VERSION.SDK_INT >= 29
                    ? HapticFeedbackConstants.CLOCK_TICK : HapticFeedbackConstants.VIRTUAL_KEY);
            refresh.run();
        };
        hours.setOnValueChangedListener(changed);
        minutes.setOnValueChangedListener(changed);
        refresh.run();

        panel.addView(confirm, new LinearLayout.LayoutParams(-1, dp(54)));
        Button cancel = button("Отмена", false, sheet::dismiss);
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(-1, dp(49));
        cancelParams.topMargin = dp(8);
        panel.addView(cancel, cancelParams);

        ScrollView wrapper = new ScrollView(this);
        wrapper.setFillViewport(false);
        wrapper.addView(panel);
        sheet.setContentView(wrapper);
        Window window = sheet.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setGravity(Gravity.BOTTOM);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.setDimAmount(0.45f);
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            window.setNavigationBarColor(WHITE);
        }
        sheet.show();
        if (window != null) {
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);
        }
    }

    private void render() {
        ticker.removeCallbacks(tick);
        countdown = null;
        timeline = null;
        controller.reconcile();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xfff5f7fb);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(30), dp(20), dp(28));
        scroll.addView(content);
        add(text("Семейный звонок", 27, BLACK, true), 6);
        add(text("Режим на время с автоматическим завершением", 15, GRAY, false), 22);

        LinearLayout statusPanel = new LinearLayout(this);
        statusPanel.setOrientation(LinearLayout.VERTICAL);
        statusPanel.setPadding(dp(18), dp(18), dp(18), dp(15));
        statusPanel.setBackground(bg(0xffe6ebf5, 16));
        status = text("", 18, BLACK, true);
        statusPanel.addView(status);
        if (controller.isActive()) {
            String time = DateFormat.getTimeInstance(DateFormat.SHORT)
                    .format(new Date(controller.until()));
            status.setText(SilenceController.modeName(controller.activeMode()) + " до " + time);
            TextView countdownTitle = text("ОСТАЛОСЬ", 12, GRAY, true);
            LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
            titleParams.topMargin = dp(15);
            statusPanel.addView(countdownTitle, titleParams);
            countdown = text("", 32, BLACK, true);
            countdown.setTypeface(android.graphics.Typeface.MONOSPACE, Typeface.BOLD);
            LinearLayout.LayoutParams timeParams = new LinearLayout.LayoutParams(-1, -2);
            timeParams.topMargin = dp(2);
            statusPanel.addView(countdown, timeParams);
            if (controller.startedAt() > 0 && controller.activeDurationMinutes() > 0) {
                timeline = new CountdownTimelineView(this);
                LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(-1, dp(60));
                progressParams.topMargin = dp(6);
                statusPanel.addView(timeline, progressParams);
            } else {
                // Sessions started in the old version have no recorded start time.
                TextView info = text("Шкала появится для следующего таймера", 12, GRAY, false);
                statusPanel.addView(info);
            }
        } else {
            String mode = controller.currentMode() == 0 ? "Телефон без звука (вручную)" :
                    controller.currentMode() == 1 ? "Режим вибрации" : "Обычный звук";
            status.setText(mode);
        }
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.bottomMargin = dp(22);
        content.addView(statusPanel, statusParams);
        if (controller.isActive()) {
            updateCountdown();
            ticker.postDelayed(tick, 1000L);
        }
        add(text("1. Режим", 17, BLACK, true), 10);
        LinearLayout modes = new LinearLayout(this);
        modes.setOrientation(LinearLayout.HORIZONTAL);
        int[] modeValues = {SilenceController.MODE_VIBRATE, SilenceController.MODE_SILENT, SilenceController.MODE_DND};
        String[] modeLabels = {"📳 Вибрация", "🔕 Без звука", "⛔ Не беспок."};
        for (int i = 0; i < modeValues.length; i++) {
            final int m = modeValues[i];
            Button choice = button(modeLabels[i], controller.chosenMode() == m,
                    () -> attempt(() -> controller.chooseMode(m)));
            choice.setTextSize(13);
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, dp(48), 1f);
            mp.setMargins(dp(2), 0, dp(3), 0);
            modes.addView(choice, mp);
        }
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(-1, -2);
        ml.bottomMargin = dp(18);
        content.addView(modes, ml);
        add(text("2. На сколько?", 17, BLACK, true), 12);
        int[] presets = {30, 60, 120, 180, 240};
        String[] labels = {"30 минут", "1 час", "2 часа", "3 часа", "4 часа"};
        for (int row = 0; row < 3; row++) {
            LinearLayout buttons = new LinearLayout(this);
            buttons.setOrientation(LinearLayout.HORIZONTAL);
            for (int col = 0; col < 2; col++) {
                int index = row * 2 + col;
                Button b;
                if (index < presets.length) {
                    final int duration = presets[index];
                    boolean selected = SessionSelection.isPresetSelected(
                            controller.isActive(), controller.activeDurationMinutes(), duration);
                    b = button(labels[index], selected,
                            () -> attempt(() -> controller.start(duration)));
                } else {
                    int activeMinutes = controller.activeDurationMinutes();
                    boolean customActive = SessionSelection.isCustomSelected(
                            controller.isActive(), activeMinutes);
                    b = button(customActive ? "Своя: " + DurationFormatter.describe(activeMinutes)
                            : "Своя длительность…", customActive, this::chooseDuration);
                }
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(54), 1f);
                p.setMargins(dp(2), 0, dp(4), 0);
                buttons.addView(b, p);
            }
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
            rowParams.bottomMargin = dp(8);
            content.addView(buttons, rowParams);
        }
        if (controller.isActive()) {
            Button stop = button("Вернуть звук сейчас", false, () -> attempt(() -> controller.stop()));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54));
            p.topMargin = dp(12);
            content.addView(stop, p);
        }
        add(text("Кнопка в шторке: последний выбранный режим на 30 минут. " +
                "Повторное нажатие останавливает таймер. Долгое нажатие открывает приложение.", 14, GRAY, false), 23);
        add(text("Проверка сигнала на своём телефоне", 17, BLACK, true), 10);
        add(text("Эти кнопки НЕ отправляют звук Алисе. Проверь, слышен ли сигнал при " +
                "вибрации, тишине и «Не беспокоить». Громкость зависит от системных " +
                "настроек будильника и аудиовыхода.", 13, GRAY, false), 10);
        LinearLayout tests = new LinearLayout(this);
        tests.setOrientation(LinearLayout.HORIZONTAL);
        Button shortTest = button("Короткий · 1 с", false, () -> signalPlayer.play(1));
        Button longTest = button("Длинный · 15 с", false, () -> signalPlayer.play(15));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, dp(52), 1f);
        tp.setMargins(dp(2), 0, dp(4), 0);
        tests.addView(shortTest, tp);
        LinearLayout.LayoutParams tp2 = new LinearLayout.LayoutParams(0, dp(52), 1f);
        tp2.setMargins(dp(2), 0, dp(4), 0);
        tests.addView(longTest, tp2);
        LinearLayout.LayoutParams testParams = new LinearLayout.LayoutParams(-1, -2);
        testParams.bottomMargin = dp(8);
        content.addView(tests, testParams);
        add(button("Остановить сигнал", false, signalPlayer::stop), 18);
        add(text("Удалённый сигнал", 17, BLACK, true), 10);
        add(button("Связать два телефона · тестовый API", false, this::showPairingSettings), 10);
        add(button("Проверить входящие сигналы сейчас", false, this::checkIncomingSignals), 10);
        add(button("Позвать Алису · настройки сигнала", false, this::showRemoteSignalSettings), 14);
        add(text("Разрешения", 17, BLACK, true), 10);
        permissions = text("", 14, GRAY, false);
        String policy = controller.hasPolicyAccess() ? "✓ Управление режимом тишины" :
                "• Нужно разрешить управление режимом тишины";
        String alarm = controller.canScheduleExact() ? "✓ Точные таймеры" :
                "• Нужно разрешить точные таймеры";
        permissions.setText(policy + "\n" + alarm);
        add(permissions, 10);
        if (!controller.hasPolicyAccess()) {
            Button allow = button("Разрешить режим тишины", false, this::openPolicyAccess);
            add(allow, 10);
        }
        if (!controller.canScheduleExact()) {
            Button allow = button("Разрешить точные таймеры", false, this::openAlarmsAccess);
            add(allow, 10);
        }
        add(text("Локальная проверка звука — не удалённый вызов. Для вызова Алисы " +
                "нужны подключение второго телефона и защищённый канал доставки. " +
                "Устройство не сообщает, что сигнал прозвучал, пока это не проверено.", 14, GRAY, false), 0);
        setContentView(scroll);
    }
}
