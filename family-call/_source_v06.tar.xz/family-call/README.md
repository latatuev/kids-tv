# Семейный звонок — Android v0.3 source prototype (local-first)

This is a working-source prototype, **not yet compiled or tested on a physical device**.
It contains NO credentials, account access, SSH, network requests or backend.

## Features
- Android Quick Settings tile **Тихо 30 мин**: tap to start 30-minute silence; tap again to return to previous ringer setting.
- Application screen: presets **30 minutes / 1 hour / 2 hours / 3 hours / 4 hours** plus a custom bottom-sheet wheel picker with live selected duration, end-time preview and tactile ticks (**1 minute–23 hours 59 minutes**); cancel immediately.
- Exact AlarmManager timer; survives app process death and restores after reboot once Android finishes booting.
- Respect manual changes back to audible/vibrate mode; never intentionally override them.
- Permissions requested openly: Notification Policy Access and Alarms & reminders.
- An active timer that began while the phone was ALREADY SILENT restores NORMAL ringer when it ends; starting from VIBRATE restores VIBRATE.

## Honest limitations and acceptance criteria
1. Real behavior on Samsung Galaxy S23 / Android 16 has **not** been tested.
2. Android can deny special permissions; app must make the refusal visible and not start a timer which cannot be accurately scheduled.
3. If permission is revoked during a timer or the phone stays powered off, no Android app can promise exact restoration at the intended moment.
4. `AudioManager.RINGER_MODE_SILENT` and system Do Not Disturb are distinct settings. The app does not claim to override *all* DND policies. OEM-specific Samsung behavior must be tested.
5. Manual ringer changes that happen while the app process is not running cannot always be distinguished from a later switch back to silent. Timer restoration checks current silent mode, which is a documented limitation.
6. This version does **not** implement spouse presence, cloud pairing, failed-call detection, or emergency override. Those need cloud integration, secure device registration, push delivery and real-phone verification. UI explicitly states that.
7. Debug signing on temporary GitHub runners changes per build. Plan a persistent signing key before regular updates.

## Build
Use Android Studio with SDK Platform 34 / JDK 17 and Gradle 8.7, or the provided manual GitHub Actions workflow `build-apk.yml` on an appropriate repository. A wrapper is omitted: GitHub job uses pinned `gradle/actions/setup-gradle`.
Gradle Android plugin: 8.5.2. No Kotlin or AndroidX dependencies required. Android minSDK 26, targetSDK 34.

## Required physical acceptance
- Grant DND policy access and exact alarms. Verify preset 30/60/120/180/240-minute restoration with phone locked; test custom 1, 45, 75, and 480 minutes.
- Quick Settings tile tap/toggle; no permission fallback.
- From NORMAL, VIBRATE, and already SILENT: verify expected restoration.
- Manually unmute before deadline: timer must not silence again.
- Revoked permission and reboot during timer: app must reflect limitations, not claim an unverified success.
- Test smartphone sleep / battery restriction behavior and note exact model/OS.

## Planned next independent component (not included in v0.1)
Use existing Yandex Cloud account, **separate** API Gateway, Cloud Function, storage/DB and cloud permissions. Do not reuse existing SpeechKit app token, audio bucket or service account credentials. Two-device secure enrollment (short-lived codes and authenticated sessions); status reports with last-seen timestamp; urgent request with explicit confirmation on sender; push + delivery acknowledgment. No Lotus operational dependency.

## 2026-10-29 — duration selection change
- Quick presets exactly: 30 minutes, 1 hour, 2 hours, 3 hours, 4 hours. No eight-hour quick preset; eight hours is selectable in the custom picker.
- Six buttons in a two-column grid; the sixth opens native hour/minute NumberPickers. Zero and durations beyond 23:59 are rejected.
- No backend dependency for any timer, including custom.
- Build and physical Android acceptance still pending; repository source changes alone do not produce an APK.

## 2026-10-29 — custom picker UX v0.2
- Replaced the ordinary input-style chooser with a rounded **bottom sheet** showing native flinging hour and minute wheels, optimized for thumb swipes.
- The user can select exact minutes (not restricted to 5-minute increments), no keyboard is needed; hours 0..23 and minutes 0..59.
- Live summary uses correct Russian plural forms and shows the estimated clock time when sound returns.
- Zero duration disables the confirmation button. Haptic clock ticks are requested when Android supports them.
- Source-only change; Android compilation and physical device acceptance remain **unverified**.

## 2026-11-03 — countdown + selected-duration fix (v0.3 sources)
- Fixed a verified UI source bug: `duration == 30` hard-coded blue styling regardless of active session. Selected preset is now read from persisted `duration_minutes` of the *active* timer; custom durations highlight the custom button; no active timer = no highlighted preset.
- Store `started_at` and `duration_minutes` together with `until` to support accurate progress after app restarts. Replacing an active session with a new duration resets timeline start, while retaining original restore mode.
- The active timer displays remaining `HH:MM:SS` updating each second while app is visible, plus elapsed-time progress with five tick marks at 0/25/50/75/100% and local clock labels.
- Existing timers created by v0.2 have no start timestamp; the countdown uses their stored expiration, while the historical progress is *not guessed* and only appears for the next timer.
- Does not change timer scheduling, notification policy access, Quick Settings tile or cloud behavior.
- SOURCE ONLY: build and physical device checks not yet performed. No GitHub Actions build performed for this revision.

## Local verification 2026-11-03
- `javac` pure-Java classes `CountdownMath`, `SessionSelection`, `SilencePolicy`, `DurationFormatter` and the standalone `tools/TestCountdown.java` harness: **83 assertions passed**.
- Android SDK / APK build / Samsung visual check **not run** for v0.3. No CI usage.


## v0.5 (source preview)
- Режимы: 📳 Вибрация, 🔕 Без звука, ⛔ Не беспок.
- «Позвать Алису»: отдельный экран конфигурации, длительность 1/2/5/10/15 секунд и уровень громкости; локальная проверка.
- Отправка на второй телефон намеренно недоступна: требуется защищённый канал, привязка устройств и тесты Android.
- Данный исходный код не является проверенным APK; сборка v0.5 пока не выполнялась.


## v0.6 development source, NOT DEPLOYED
- New `RelayClient` uses HTTPS only, explicit pairing, device registration, 15s TTL and bounded signals.
- Manual send and manual foreground inbox retrieval, with an acknowledgement that means requested, NOT audibly heard.
- No FCM, no foreground service, no notification-driven wake, no Yandex deployment.
- Only use endpoint under your control. The SQLite/FastAPI backend is a test fixture and MUST NOT be exposed publicly.
- Credentials stored in Android private preferences (not Keystore); production must use encryption, account revocation and device attestation/abuse limits.
- No APK build or physical Samsung test verified.
