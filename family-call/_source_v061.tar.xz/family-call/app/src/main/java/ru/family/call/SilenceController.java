package ru.family.call;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Build;
import android.service.quicksettings.TileService;

/** All timers are local to the phone. No network or cloud privileges. */
public final class SilenceController {
    public static final int MODE_SILENT = 0;
    public static final int MODE_VIBRATE = 1;
    public static final int MODE_DND = 3;
    public static final String ACTION_EXPIRE = "ru.family.call.EXPIRE";
    private static final String PREFS = "silence-state";
    private static final String ACTIVE = "active", UNTIL = "until", STARTED = "started_at";
    private static final String DURATION = "duration_minutes", RESTORE = "restore_mode";
    private static final String RESTORE_DND = "restore_dnd", ACTIVE_MODE = "active_mode", CHOICE = "chosen_mode";
    private static final String LAST_RESULT = "last_timer_result";

    private final Context context;
    private final SharedPreferences prefs;
    private final AlarmManager alarms;
    private final AudioManager audio;
    private final NotificationManager notification;

    public SilenceController(Context context) {
        this.context = context.getApplicationContext();
        prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        alarms = (AlarmManager) this.context.getSystemService(Context.ALARM_SERVICE);
        audio = (AudioManager) this.context.getSystemService(Context.AUDIO_SERVICE);
        notification = (NotificationManager) this.context.getSystemService(Context.NOTIFICATION_SERVICE);
    }
    public boolean hasPolicyAccess() { return notification.isNotificationPolicyAccessGranted(); }
    public boolean canScheduleExact() { return Build.VERSION.SDK_INT < 31 || alarms.canScheduleExactAlarms(); }
    public boolean ready() { return hasPolicyAccess() && canScheduleExact(); }
    public boolean isActive() { return prefs.getBoolean(ACTIVE, false); }
    public long until() { return prefs.getLong(UNTIL, 0); }
    public long startedAt() { return prefs.getLong(STARTED, 0); }
    public int activeDurationMinutes() { return prefs.getInt(DURATION, 0); }
    public int currentMode() { return audio.getRingerMode(); }
    public int currentDnd() { return notification.getCurrentInterruptionFilter(); }
    public int activeMode() { return prefs.getInt(ACTIVE_MODE, MODE_SILENT); } // v0.3 migration
    public int chosenMode() { return prefs.getInt(CHOICE, MODE_VIBRATE); }
    public String lastTimerResult() { return prefs.getString(LAST_RESULT, ""); }
    public void chooseMode(int mode) {
        if (!isValidMode(mode)) throw new IllegalArgumentException("Неизвестный режим");
        prefs.edit().putInt(CHOICE, mode).apply();
        updateTile(context);
    }
    public static boolean isValidMode(int mode) {
        return mode == MODE_SILENT || mode == MODE_VIBRATE || mode == MODE_DND;
    }
    public static String modeName(int mode) {
        if (mode == MODE_VIBRATE) return "Вибрация";
        if (mode == MODE_DND) return "Не беспокоить";
        return "Без звука";
    }

    private PendingIntent alarmIntent() {
        Intent intent = new Intent(context, AlarmReceiver.class).setAction(ACTION_EXPIRE);
        return PendingIntent.getBroadcast(context, 491, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private PendingIntent showAlarmIntent() {
        Intent intent = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(context, 492, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /**
     * Restore mode at the promised wall-clock time. Unlike setExactAndAllowWhileIdle,
     * setAlarmClock is not subject to while-idle alarm dispatch throttling.
     * The OS may display this as an upcoming alarm; this receiver itself plays no sound.
     */
    private void scheduleExpiry(long when) {
        alarms.setAlarmClock(new AlarmManager.AlarmClockInfo(when, showAlarmIntent()), alarmIntent());
    }

    private static String ringerLabel(int mode) {
        if (mode == AudioManager.RINGER_MODE_NORMAL) return "со звуком";
        if (mode == AudioManager.RINGER_MODE_VIBRATE) return "вибрация";
        return "без звука";
    }

    /** Start or replace a session. The first session captures the user's original settings. */
    public void start(int minutes) {
        if (!SilencePolicy.validDuration(minutes)) throw new IllegalArgumentException("Выбери от 1 мин до 23 ч 59 мин.");
        if (!ready()) throw new IllegalStateException("Предоставь доступ к режиму тишины и точным таймерам.");
        int target = chosenMode();
        int originalRinger = isActive() ? prefs.getInt(RESTORE, AudioManager.RINGER_MODE_NORMAL)
                : SilencePolicy.restoreMode(audio.getRingerMode());
        int originalDnd = isActive() ? prefs.getInt(RESTORE_DND, NotificationManager.INTERRUPTION_FILTER_ALL)
                : notification.getCurrentInterruptionFilter();
        long now = System.currentTimeMillis(), end = now + minutes * 60_000L;
        // A replacement timer must survive failure when applying the new mode.
        boolean hadSession = isActive();
        long oldDeadline = hadSession ? until() : 0;
        int priorRinger = audio.getRingerMode();
        int priorDnd = notification.getCurrentInterruptionFilter();
        int oldMode = isActive() ? activeMode() : -1;
        try {
            scheduleExpiry(end);
            // Only undo the DND setting that this app applied; preserve a pre-existing DND setting.
            if (oldMode == MODE_DND && target != MODE_DND && priorDnd == NotificationManager.INTERRUPTION_FILTER_ALARMS)
                notification.setInterruptionFilter(originalDnd);
            if (target == MODE_DND) {
                // Alarms remain enabled, while ordinary calls and notifications are muted.
                notification.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS);
            } else {
                audio.setRingerMode(target == MODE_VIBRATE
                        ? AudioManager.RINGER_MODE_VIBRATE : AudioManager.RINGER_MODE_SILENT);
                if (audio.getRingerMode() != target) throw new IllegalStateException("Android не разрешил сменить режим звука.");
            }
            if (oldMode != -1 && oldMode != MODE_DND && target == MODE_DND) {
                // Restore audible ringing immediately; DND itself suppresses interruptions.
                audio.setRingerMode(originalRinger);
            }
            if (target == MODE_DND && notification.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALARMS)
                throw new IllegalStateException("Android не разрешил включить «Не беспокоить».");
            if (!prefs.edit().putBoolean(ACTIVE, true).putLong(UNTIL, end)
                    .putLong(STARTED, now).putInt(DURATION, minutes)
                    .putInt(RESTORE, originalRinger).putInt(RESTORE_DND, originalDnd)
                    .putInt(ACTIVE_MODE, target).putString(LAST_RESULT, "").commit()) throw new IllegalStateException("Не удалось сохранить таймер.");
            updateTile(context);
        } catch (Exception e) {
            alarms.cancel(alarmIntent());
            // Reinstall the previous alarm if a timer replacement failed midway.
            if (hadSession && oldDeadline > System.currentTimeMillis() && canScheduleExact()) {
                try { scheduleExpiry(oldDeadline); }
                catch (RuntimeException rollbackError) {
                    android.util.Log.e("FamilyCallTimer", "Could not restore previous alarm", rollbackError);
                }
            }
            try { if (audio.getRingerMode() != priorRinger) audio.setRingerMode(priorRinger); }
            catch (Exception ignored) {}
            try { if (notification.getCurrentInterruptionFilter() != priorDnd)
                notification.setInterruptionFilter(priorDnd); }
            catch (Exception ignored) {}
            throw new IllegalStateException("Не удалось включить режим: " + e.getMessage(), e);
        }
    }

    /** User-invoked cancellation. Do not override changes made after session started. */
    public void stop() {
        if (!isActive()) return;
        String result = restoreCurrentIfStillOurs();
        clearState();
        prefs.edit().putString(LAST_RESULT, "Таймер остановлен. " + result).apply();
    }
    /** Returns the actual attempted restoration, not simply whether the timer expired. */
    private String restoreCurrentIfStillOurs() {
        int mode = activeMode();
        if (mode == MODE_DND) {
            if (notification.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALARMS)
                return "Настройки «Не беспокоить» изменились; не вмешиваюсь.";
            int previous = prefs.getInt(RESTORE_DND, NotificationManager.INTERRUPTION_FILTER_ALL);
            notification.setInterruptionFilter(previous);
            if (notification.getCurrentInterruptionFilter() != previous)
                throw new IllegalStateException("Android не подтвердил восстановление «Не беспокоить»");
            return "Восстановлен прежний режим «Не беспокоить».";
        }
        if (audio.getRingerMode() != mode)
            return "Режим звука уже изменён; не вмешиваюсь.";
        int original = prefs.getInt(RESTORE, AudioManager.RINGER_MODE_NORMAL);
        audio.setRingerMode(original);
        if (audio.getRingerMode() != original)
            throw new IllegalStateException("Android не подтвердил восстановление звука");
        return "Восстановлен прежний режим: " + ringerLabel(original) + ".";
    }
    private boolean manuallyChanged() {
        if (activeMode() == MODE_DND)
            return notification.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALARMS;
        return audio.getRingerMode() != activeMode();
    }
    private void clearState() {
        alarms.cancel(alarmIntent());
        prefs.edit().putBoolean(ACTIVE, false).remove(UNTIL).remove(STARTED).remove(DURATION)
                .remove(RESTORE).remove(RESTORE_DND).remove(ACTIVE_MODE).commit();
        updateTile(context);
    }
    public void reconcile() {
        if (!isActive()) return;
        if (System.currentTimeMillis() >= until()) {
            final String result;
            try { result = restoreCurrentIfStillOurs(); }
            catch (RuntimeException e) {
                // Keep the session for a later retry if Android rejects restoration.
                prefs.edit().putString(LAST_RESULT,
                        "Не удалось вернуть режим: " + e.getClass().getSimpleName()).apply();
                android.util.Log.e("FamilyCallTimer", "Expiry restoration failed", e);
                // A transient Android error must not permanently orphan an expired session.
                if (canScheduleExact()) {
                    try { scheduleExpiry(System.currentTimeMillis() + 60_000L); }
                    catch (RuntimeException retryError) {
                        android.util.Log.e("FamilyCallTimer", "Could not schedule restoration retry", retryError);
                    }
                }
                return;
            }
            clearState();
            prefs.edit().putString(LAST_RESULT, "Таймер завершён. " + result).apply();
        } else if (manuallyChanged()) {
            clearState();
            prefs.edit().putString(LAST_RESULT,
                    "Таймер отменён: режим изменён на телефоне. Настройки сохранены.").apply();
        }
    }
    public void restoreAlarmAfterBootOrPermission() {
        if (!isActive()) return;
        if (System.currentTimeMillis() >= until()) { reconcile(); return; }
        if (canScheduleExact()) {
            try { scheduleExpiry(until()); }
            catch (SecurityException ignored) {}
        }
        updateTile(context);
    }
    public static void updateTile(Context context) {
        TileService.requestListeningState(context, new ComponentName(context, SilenceTileService.class));
    }
}
