package ru.family.call;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Explicit, foreground-only integration with a trusted, owner-configured HTTPS relay.
 * No embedded cloud credential, Firebase token, background polling or silent remote control.
 */
public final class RelayClient {
    public interface Callback { void completed(JSONObject data, Exception error); }
    private final SharedPreferences prefs;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    public RelayClient(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences("family_call_relay_v1", Context.MODE_PRIVATE);
    }
    public boolean configured() { return !prefs.getString("url", "").isEmpty(); }
    public boolean registered() { return !prefs.getString("device_id", "").isEmpty(); }
    public String getDeviceId() { return prefs.getString("device_id", ""); }
    public String endpoint() { return prefs.getString("url", ""); }
    public void setEndpoint(String address) {
        try {
            URL url = new URL(address.trim());
            if (!"https".equalsIgnoreCase(url.getProtocol()) || url.getHost().isEmpty()
                    || url.getUserInfo()!=null || url.getPort() != -1 || !url.getPath().isEmpty()
                    && !"/".equals(url.getPath()) || url.getQuery()!=null || url.getRef()!=null) {
                throw new IllegalArgumentException("Нужен HTTPS-адрес API без пути, порта и параметров");
            }
            String normalized = "https://" + url.getHost();
            if (!normalized.equals(prefs.getString("url", ""))) {
                prefs.edit().clear().putString("url", normalized).apply();
            }
        } catch (java.net.MalformedURLException e) {
            throw new IllegalArgumentException("Некорректный HTTPS-адрес", e);
        }
    }
    private static JSONObject fields(Object... keyValues) {
        JSONObject result = new JSONObject();
        try {
            for (int i=0; i<keyValues.length; i+=2) result.put((String)keyValues[i], keyValues[i+1]);
        } catch (org.json.JSONException e) { throw new IllegalArgumentException("JSON serialization failed",e); }
        return result;
    }
    public void register(String name, Callback callback) {
        execute("POST", "/v1/devices", fields("label", name), false, (data, err) -> {
            if (err == null) {
                prefs.edit().putString("device_id", data.optString("device_id"))
                        .putString("token", data.optString("token")).apply();
            }
            callback.completed(data, err);
        });
    }
    public void invite(Callback c) { execute("POST", path("/invites"), new JSONObject(), true, c); }
    public void pair(String code, Callback c) {
        if (!code.matches("[0-9]{8}")) { c.completed(null, new IllegalArgumentException("Введите 8 цифр")); return; }
        execute("POST", path("/pair"), fields("code", code), true, c);
    }
    public void send(boolean longSignal, int seconds, int volume, Callback c) {
        if (seconds < 1 || seconds > 30 || volume < 0 || volume > 100) {
            c.completed(null, new IllegalArgumentException("Недопустимая длительность или громкость")); return;
        }
        execute("POST", path("/signals"), fields("kind", longSignal ? "long":"short", "seconds", seconds, "volume", volume), true, c);
    }
    public void inbox(Callback c) { execute("GET", path("/signals"), null, true, c); }
    public void ack(String id, boolean played, Callback c) {
        if (!id.matches("[A-Za-z0-9_-]{10,80}")) throw new IllegalArgumentException("Invalid signal ID");
        execute("POST", path("/signals/" + id + "/ack"),
                fields("state", played ? "played":"failed"), true, c);
    }
    private String path(String tail) {
        if (!registered()) throw new IllegalStateException("Зарегистрируйте телефон");
        return "/v1/devices/" + getDeviceId() + tail;
    }
    private void execute(String method, String path, JSONObject body, boolean auth, Callback callback) {
        io.execute(() -> {
            HttpURLConnection conn = null;
            try {
                if (!configured()) throw new IllegalStateException("Не задан HTTPS-адрес сервера");
                URL url = new URL(endpoint() + path);
                conn = (HttpURLConnection) url.openConnection();
                conn.setInstanceFollowRedirects(false);  // never forward bearer to redirected host
                conn.setConnectTimeout(6000);
                conn.setReadTimeout(6000);
                conn.setRequestMethod(method);
                conn.setRequestProperty("Accept", "application/json");
                if (auth) conn.setRequestProperty("Authorization", "Bearer " + prefs.getString("token", ""));
                if (body != null) {
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    byte[] raw = body.toString().getBytes(StandardCharsets.UTF_8);
                    if (raw.length > 4096) throw new IllegalArgumentException("Payload too large");
                    try (OutputStream out = conn.getOutputStream()) { out.write(raw); }
                }
                int status = conn.getResponseCode();
                if (status < 200 || status >= 300) throw new IllegalStateException("Ошибка сервера HTTP " + status);
                byte[] raw;
                try (InputStream stream = conn.getInputStream()) { raw = readBounded(stream, 32768); }
                callback.completed(new JSONObject(new String(raw, StandardCharsets.UTF_8)), null);
            } catch (Exception error) { callback.completed(null, error); }
            finally { if (conn != null) conn.disconnect(); }
        });
    }
    private static byte[] readBounded(InputStream in, int maxBytes) throws java.io.IOException {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] b = new byte[4096]; int n;
        while ((n = in.read(b)) != -1) {
            if (out.size() + n > maxBytes) throw new java.io.IOException("Response exceeds limit");
            out.write(b, 0, n);
        }
        return out.toByteArray();
    }
}
